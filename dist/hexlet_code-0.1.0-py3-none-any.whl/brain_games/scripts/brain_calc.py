#!/usr/bin/env python3

import brain_games.cli
from brain_games.cli import welcome, user_answer, check, number_count, end_game
import random


def main():
    name = welcome()
    count = number_count()
    correct_count = 0
    operations = ['+', '-', '*']
    print('What is the result of the expression?')
    for _ in range(count):
        a = random.randint(1, 100)
        b = random.randint(1, 100)
        operation = random.choice(operations)
        if operation == '+':
            correct = a + b
        elif operation == '-':
            correct = a - b
        elif operation == '*':
            correct = a * b
        print(f'Question: {a} {operation} {b}')
        answer = user_answer()
        if check(name, answer, correct):
            correct_count += 1
            if end_game(name, correct_count):
                break
        else:
            end_game(name, correct_count)
            break


if __name__ == '__main__':
    main()
