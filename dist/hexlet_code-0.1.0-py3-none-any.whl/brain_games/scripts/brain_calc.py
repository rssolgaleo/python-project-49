#!/usr/bin/env python3

from brain_games.calc import play


def main():
    play()


if __name__ == '__main__':
    main()
