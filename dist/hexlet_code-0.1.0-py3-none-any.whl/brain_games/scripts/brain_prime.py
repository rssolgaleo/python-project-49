#!/usr/bin/env python3

from brain_games.prime import play


def main():
    play()


if __name__ == "__main__":
    main()
