### Hexlet tests and linter status:
[![Actions Status](https://github.com/rssolgaleo/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/rssolgaleo/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/093e290cc899e1f728c1/maintainability)](https://codeclimate.com/github/rssolgaleo/python-project-49/maintainability)

[brain-even](https://asciinema.org/a/671608)
