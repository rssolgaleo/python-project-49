### Hexlet tests and linter status:

[![Actions Status](https://github.com/rssolgaleo/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/rssolgaleo/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/093e290cc899e1f728c1/maintainability)](https://codeclimate.com/github/rssolgaleo/python-project-49/maintainability)

[brain-even](https://asciinema.org/a/671608)

[brain-calc](https://asciinema.org/a/3XRHqHrSkUXeBO0PJOXAK1DK4)

[brain-gcd](https://asciinema.org/a/jMj3L6UxxC6QOPFm0glkDOPvJ)
