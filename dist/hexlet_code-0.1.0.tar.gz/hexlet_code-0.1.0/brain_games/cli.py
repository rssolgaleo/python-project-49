import prompt


def welcome():
    print("Welcome to the Brain Games!")
    name = prompt.string('May I have your name? ')
    print(f"Hello, {name}!")
    return name


def number_count():
    return 3


def user_answer():
    answer = input("Your answer: ")
    return answer


def check(name, answer, right):
    if answer == right:
        print("Correct!")
        return True
    else:
        say_bye(name, answer, right)


def say_bye(name, answ, right):
    print(f"'{answ}' is wrong answer ;(. Correct answer was '{right}'.")
    print(f"Let's try again, {name}!")
    return False


def end_game(name, count):
    if count == 3:
        print(f"Congratulations, {name}!")
        return True
    return False
