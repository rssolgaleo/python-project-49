#!/usr/bin/env python3

from brain_games.prime import play



def main():
    print('1')
    play()


if __name__ == "__main__":
    main()
