#!/usr/bin/env python3

from brain_games.progress_game import progress_game


def main():
    progress_game('prime')


if __name__ == "__main__":
    main()
