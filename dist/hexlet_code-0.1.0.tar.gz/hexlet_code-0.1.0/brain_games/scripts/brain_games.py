#!/usr/bin/env python3

from brain_games.cli import hi


def main():
    hi()


if __name__ == "__main__":
    main()
