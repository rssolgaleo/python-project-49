#!/usr/bin/env python3

from brain_games.gcd import play


def main():
    play()


if __name__ == "__main__":
    main()
