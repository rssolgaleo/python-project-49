#!/usr/bin/env python3

from brain_games.progress_game import play
from brain_games.even import is_even


def main():
    text: str = 'Answer "yes" if the number is even, otherwise answer "no".'
    play(is_even, text)
    #text: str = 'Answer "yes" if the number is even, otherwise answer "no".'
    #progress_game(is_even, text)


if __name__ == "__main__":
    main()
