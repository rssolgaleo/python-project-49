def constant(func):
    if func == "is_even":
        return 'Answer "yes" if the number is even, otherwise answer "no".'
    else:
        return
